import math
North=math.copysign(0.3,-1)
print North

'''set=(1,2,3)
newSet=[]
print set
for x in set:
	newSet.append(x*3)
print newSet'''